# Discord-Raider-Pro
![PictureLogo](https://i.ibb.co/khPHthN/discord-128-ico-removebg-preview.png)

## About
This tool is used for educational purposes only. Windows is only supported right now.

## Picture
![Picture](https://i.ibb.co/hVQgWK7/Screenshot-199.png)

## How to use
- Python must be installed

1. If you dont have python installed, download python 3.7.6
and make sure you click on the 'ADD TO PATH' option during
the installation.

2. pip install requirements ```pip install -r requirements.txt``` or you can run the .bat file. The .bat file automatically pip installs the requirements for you (if you get an error while installing PyNacl, try running cmd as administrator)

3. ffmpeg is required if you want to play music. Download choco then ```choco install ffmpeg```, or you can run ffmpeg.ps1 by right clicking and clicking 'run with powershell'. ffmpeg.ps1 automatically installs choco and ffmpeg for you. 

4.  Make sure you are in the same directory as the folder you downloaded it in.  Type
```python main.py``` in cmd to run or you can run the .bat file.

5. Add tokens to the program; open the text file with your discord tokens

## Features 
- Status Changer
- Server Joiner
- Server Leaver
- Text Spam
- Voice Channel Joiner
- Voice Channel Leaver
- Voice Channel Music Player/ Spam
- Message Reaction Adder
- Embed Spammer
- Fake Typing
