from raid import join_vc
join_vc()