from raid import fake_typing

fake_typing()