from raid import text_spam
text_spam()