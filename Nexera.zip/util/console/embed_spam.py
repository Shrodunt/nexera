from raid import embed_spam

embed_spam()