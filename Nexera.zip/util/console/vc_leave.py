from raid import leave_vc
leave_vc()