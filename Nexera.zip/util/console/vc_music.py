from raid import music_spammer
music_spammer()