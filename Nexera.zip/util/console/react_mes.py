from raid import reaction_adder

reaction_adder()