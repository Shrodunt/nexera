class Container:
    def __init__(self):
        print('Nexero Spammer v0.1 by Fold#5661')
        print('This is open sourced. if anyone sells you this, you have gotten scammed. | discord.gg/e8Qy8JKbUK')
        self.file_path = None
        self.tokens = None

    def add_file_path(self, file_path):
        self.file_path = file_path

    def get_file_path(self):
        return self.file_path

    def add_tokens(self, tokens):
        self.tokens =tokens

    def get_tokens(self):
        return self.tokens

