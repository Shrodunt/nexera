from .ui_main import Ui_MainWindow
from .ui_functions import *
from .logic_functions import * 